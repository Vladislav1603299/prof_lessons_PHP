-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Фев 02 2022 г., 18:23
-- Версия сервера: 5.6.51
-- Версия PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `goods_catalog`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `price`, `image`) VALUES
(1, 'Product 1', 100, 'img/1.jpeg'),
(2, 'Product 2', 200, 'img/1.jpeg'),
(3, 'Product 3', 300, 'img/1.jpeg'),
(4, 'Product 4', 400, 'img/1.jpeg'),
(5, 'Product 5', 500, 'img/1.jpeg'),
(6, 'Product 6', 600, 'img/1.jpeg'),
(7, 'Product 7', 700, 'img/1.jpeg'),
(8, 'Product 8', 800, 'img/1.jpeg'),
(9, 'Product 9', 900, 'img/1.jpeg'),
(10, 'Product 10', 1000, 'img/1.jpeg'),
(11, 'Product 11', 1100, 'img/1.jpeg'),
(12, 'Product 12', 1200, 'img/1.jpeg'),
(13, 'Product 13', 1300, 'img/1.jpeg'),
(14, 'Product 14', 1400, 'img/1.jpeg'),
(15, 'Product 15', 1500, 'img/1.jpeg'),
(16, 'Product 16', 1600, 'img/1.jpeg'),
(17, 'Product 17', 1700, 'img/1.jpeg'),
(18, 'Product 18', 1800, 'img/1.jpeg'),
(19, 'Product 19', 1900, 'img/1.jpeg'),
(20, 'Product 20', 2000, 'img/1.jpeg'),
(21, 'Product 21', 2100, 'img/1.jpeg'),
(22, 'Product 22', 2200, 'img/1.jpeg'),
(23, 'Product 23', 2300, 'img/1.jpeg'),
(24, 'Product 24', 2400, 'img/1.jpeg'),
(25, 'Product 25', 2500, 'img/1.jpeg');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
